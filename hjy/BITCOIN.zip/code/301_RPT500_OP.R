# title : 301_RPT500_OP
# author : hjy

# run model 
rmarkdown::render(file.path(PATH_HOME,"code","301_RPT500_OP.Rmd"), output_dir = PATH_HOME)

# ���
cat(">> 301 done! \n")
