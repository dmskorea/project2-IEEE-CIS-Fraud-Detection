# title : BTC500
# author : hjy

# save memory
rm(list=ls())
gc(reset=T)

# options
options(scipen = 999)
Sys.setlocale("LC_TIME", "English")

# library
.libPaths("c:/RLIB")
library(cryptor,lib.loc = "C:/Users/user/Documents/R/win-library/3.5")
library(data.table)
library(plotly)
library(lubridate)
library(pracma)
library(caTools)
library(h2o)
library(htmltools)
library(htmlwidgets)

# user functions
range01 = function(x){(x-min(x))/(max(x)-min(x))}
"%ni%" = Negate("%in%")

# set PATH
PATH_HOME = "c:/Users/user/Documents/BITCOIN"

# h2o
h2o.init()
h2o.removeAll()

# predict_days 
predict_days = 3

# train options (1hour: 60*60)
max_runtime_secs = 60*60
max_models = 100
nfolds = 10
stopping_rounds = 30
stopping_tolerance = 0.001
simple = TRUE

# BTC
COIN_NAME = "BTC"
source(file.path(PATH_HOME,"code","101_BTC500_DM.R"))
COIN_NAME = "BCH"
source(file.path(PATH_HOME,"code","101_BTC500_DM.R"))

# title : 201_BTC500_ML.R
# author : hjy

# data_TMP
data_TMP = data
colnames(data_TMP) = paste0("x",1:ncol(data))
data.table(colnames(data_TMP),colnames(data))[V2=="time"]
data.table(colnames(data_TMP),colnames(data))[V2=="date"]
data.table(colnames(data_TMP),colnames(data))[V2=="open"]
data.table(colnames(data_TMP),colnames(data))[V2=="close"]
data.table(colnames(data_TMP),colnames(data))[V2=="high"]
data.table(colnames(data_TMP),colnames(data))[V2=="low"]

# shift
data_TMP[,':='(x1=NULL,x8=NULL)]
data_TMP[,TARGET:=shift(x2,predict_days,type="lead")]
newdata = data_TMP[is.na(TARGET),]
xydata = data_TMP[!is.na(TARGET),]
head(data_TMP)

# h2o
h2o.removeAll()

# data h2oframe
data_hex = as.h2o(xydata)
head(data_hex)

# newdata h2oframe
newdata_hex = as.h2o(newdata)
head(newdata_hex)

# set x and y 
x = colnames(data_hex)[colnames(data_hex) %ni% c('TARGET')]
y = 'TARGET'

# ml  
ml = h2o.randomForest(
  training_frame = data_hex,
  x = x,
  y = y,
  nfolds = nfolds,
  stopping_rounds = stopping_rounds,
  stopping_tolerance = stopping_tolerance,
  stopping_metric = "RMSLE",
  seed = 201
)

ml = h2o.gbm(
  training_frame = data_hex,
  x = as.data.table(ml@model$variable_importances)[relative_importance!=0,variable],
  y = y,
  nfolds = nfolds,
  stopping_rounds = stopping_rounds,
  stopping_tolerance = stopping_tolerance,
  stopping_metric = "RMSLE",
  seed = 201
)
h2o.performance(ml,xval = T)
"
MSE:  18456768718
RMSE:  135855.7
MAE:  65002.18
RMSLE:  0.1003614
Mean Residual Deviance :  18456768718
"

ml = h2o.gbm(
  training_frame = data_hex,
  x = as.data.table(ml@model$variable_importances)[relative_importance!=0,variable],
  y = y,
  nfolds = nfolds,
  stopping_rounds = stopping_rounds,
  stopping_tolerance = stopping_tolerance,
  stopping_metric = "RMSLE",
  seed = 201
)
h2o.performance(ml,xval = T)
"
MSE:  18410516329
RMSE:  135685.4
MAE:  64535.94
RMSLE:  0.09862542
Mean Residual Deviance :  18410516329
"
x_tmp = as.data.table(ml@model$variable_importances)[relative_importance!=0,variable]
length(x_tmp)


ml = h2o.gbm(
  training_frame = data_hex,
  x = x_tmp[1:70],
  y = y,
  nfolds = 15,
  ntrees = 1000,
  max_depth = 4,
  stopping_rounds = 50,
  stopping_tolerance = 0.0001,
  stopping_metric = "RMSLE",
  seed = 201
)
h2o.performance(ml,xval = T)
"
MSE:  15857295052
RMSE:  125925.8
MAE:  56084.39
RMSLE:  0.08366373
Mean Residual Deviance :  15857295052
"

ml = h2o.gbm(
  training_frame = data_hex,
  x = x_tmp[1:70],
  y = y,
  nfolds = 15,
  ntrees = 1000,
  max_depth = 4,
  learn_rate = 0.1,
  stopping_rounds = 50,
  stopping_tolerance = 0.0001,
  stopping_metric = "RMSLE",
  seed = 201
)
h2o.performance(ml,xval = T)
































